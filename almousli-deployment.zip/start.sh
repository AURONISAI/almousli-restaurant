﻿#!/bin/bash
echo 'Starting Almousli Restaurant...'
npm start
