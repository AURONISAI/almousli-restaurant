﻿#!/bin/bash
echo '========================================'
echo 'Almousli Restaurant - Installation'
echo '========================================'
echo 'Installing production dependencies...'
npm install --production
echo ''
echo ' Installation complete!'
echo ''
echo 'To start the server, run:'
echo '  npm start'
echo ''
echo 'The website will run on port 3000'
echo '========================================'
